#ifndef TESTFIRST_LIBVEC_H
#define TESTFIRST_LIBVEC_H


class libVec {
public:
    long int counter(int n);

};


#endif