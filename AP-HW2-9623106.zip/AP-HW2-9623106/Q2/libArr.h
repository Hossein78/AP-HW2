#ifndef TESTFIRST_LIBARR_H
#define TESTFIRST_LIBARR_H


class libArr {
public:
    long int counter(int n);

};


#endif
